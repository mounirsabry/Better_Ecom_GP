-- do not forget to use the specific database you want to execute the script on.

DROP TABLE IF EXISTS instructor_course_instance_registration;
DROP TABLE IF EXISTS student_course_instance_registration;
DROP TABLE IF EXISTS course_instance_late_registration_request;
DROP TABLE IF EXISTS course_prerequisite;
DROP TABLE IF EXISTS course_department_applicability;
DROP TABLE IF EXISTS course_instance;
DROP TABLE IF EXISTS course;
DROP TABLE IF EXISTS student_department_priority_list;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS instructor;
DROP TABLE IF EXISTS department;
DROP TABLE IF EXISTS admin_user;
DROP TABLE IF EXISTS system_user;
