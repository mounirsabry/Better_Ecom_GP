﻿namespace Better_Ecom_Backend.Models
{
    public enum Term
    {
        First,
        Second,
        Summer,
        Other,
    }
}
