﻿namespace Better_Ecom_Backend.Models
{
    public enum LateRegistrationRequestStatus
    {
        Pending_Accept,
        Accepted,
        Rejected
    }
}
